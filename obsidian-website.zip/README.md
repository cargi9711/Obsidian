# Obsidian Website Project

A dark-themed static website inspired by obsidian stone.

## Features
- Elegant dark UI
- Responsive grid system
- Clean and modern layout

## Usage
1. Download ZIP
2. Extract files
3. Open index.html in browser

## Author
Gudhal Production
